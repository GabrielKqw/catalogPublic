export const jwtConstants = {
  secret: 'tokyoghoulsecretkey2025',
};
